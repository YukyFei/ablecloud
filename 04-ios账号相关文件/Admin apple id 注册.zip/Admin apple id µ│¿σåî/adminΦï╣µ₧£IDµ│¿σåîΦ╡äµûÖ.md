# 苹果ID

## 账号

admin@ablecloud.cn

## 密码

ADMINablecloud2018

### 姓名

孙志东

### 出生日期

1982.10.29

### 密码提示问题

1. 你的第一个宠物叫什么名字?(小明)
2. 你的理想工作是什么?(科学家)
3. 您最喜欢的那个球队?(马刺)

# 开发者信息

Email: admin@ablecloud.cn
Name: 志东 孙
Country: China

Entity Type: Company / Organization

Organization Information
Legal Entity Name: Beijing AbleCloud Technology Co., Ltd.
D-U-N-S® Number: 544435066
Website: https://www.ablecloud.cn
Headquarters Phone: 86 010-59448517

Address:
Beyondsoft Headquarters, Bldg. 7, East Zone, Courtyard #10, Xibeiwang East Road, Haidian District,
Beijing, Beijing 100193
CN


